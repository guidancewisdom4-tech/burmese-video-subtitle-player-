# Burmese Video Subtitle Player

Android app (Kotlin, minSdk 26, targetSdk 34) that plays a video with
Media3 / ExoPlayer, loads an existing `.srt`, or generates Burmese
subtitles from the spoken English using Gemini `gemini-2.5-flash`.

## How to build

1. Open this folder in Android Studio (Hedgehog or newer, JDK 17).
2. Let Gradle sync. No local.properties secret is needed.
3. Run on a device or emulator (API 26+).
4. Or from the command line:
   ```
   ./gradlew assembleDebug
   ```
   The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## How to use

1. Tap **Settings**, paste your Gemini API key, keep the model as
   `gemini-2.5-flash`, choose a segment length (default 45 s) and save.
   The key is stored with EncryptedSharedPreferences and is sent only
   to Google's Gemini API over HTTPS. Get a key at Google AI Studio
   (https://aistudio.google.com).
2. Tap **Pick Video** and choose a video file from storage.
3. Either:
   - Tap **Load .srt** to pair an existing subtitle file — no API call
     is made, or
   - Tap **Generate Subtitles** to transcribe + translate with Gemini.
4. Watch the progress bar: percentage, completed / total segments,
   and the current segment with its time range. If a segment fails,
   tap **Retry Failed**. If you pause or the app closes, tap **Resume**
   — completed segments and cues are saved in
   `generation_progress.json` in internal storage and are not redone.
5. Subtitles appear synchronised over the video. Use the switch to
   toggle them, the sliders for Burmese font size (12–36 sp) and
   background opacity (0–100%).
6. Tap any line in the subtitle list to edit its text, start time or
   end time, or delete it.
7. Tap **Export .srt** to save the final file with the system picker.

## How generation works

- `AudioSegmenter` uses `MediaExtractor` + `MediaMuxer` to split the
  video's audio track into standalone `.m4a` segments in the cache
  directory — no external native binary is needed.
- `GeminiRepository` sends each segment (base64 audio + prompt) to
  `POST v1beta/models/gemini-2.5-flash:generateContent`. The prompt
  asks for transcription, then natural Burmese translation, returned
  as SRT with times relative to the segment start. The repository
  shifts those times to absolute video time and retries a segment up
  to 3 times before marking it FAILED.
- `PlayerViewModel` keeps per-segment status, persists progress after
  every segment, and resumes only PENDING / FAILED segments.

## Islamic terminology

`IslamicGlossary` defines the canonical Burmese renderings used
everywhere — in the Gemini prompt for every segment, and again as a
post-processing check on generated text:

Allah → အလ္လာဟ်, Prophet/Messenger → တမန်တော်,
Quran → ကုရ်အာန်, Hadith → ဟဒီးစ်, Sunnah → စွန္နသ်,
Salah → ဆွလားသ်, Dua → ဒိုအာ, Dhikr → ဇိကိရ်,
Tawheed → သဝ်ဟီးဒ်, Taqwa → သက္ကဝါ,
Halal → ဟလာလ်, Haram → ဟရာမ်, Ummah → အွမ္မသ်,
and more (see the in-app Glossary button for the full list).

The prompt explicitly forbids literal mistranslations and irreverent
phrasing for Allah, the Prophet, the Quran and worship. These are
translation conventions, not religious rulings — disputed matters are
kept as transliterations, and the app does not issue rulings.

## Project structure

```
app/src/main/AndroidManifest.xml
app/src/main/java/com/burmese/subtitleplayer/
  MainActivity.kt                 Player UI, pickers, overlay, editing, export
  data/
    SubtitleCue.kt                Cue model, SRT time format/parse, segment state
    SrtParser.kt                  Parse / serialise / lookup / shift SRT
    IslamicGlossary.kt            Canonical Burmese terms + prompt block + fixes
    SettingsManager.kt            Encrypted API key, model, display prefs
    AudioSegmenter.kt             MediaExtractor/MediaMuxer audio splitting
    GeminiApi.kt                  Retrofit service + Gemini DTOs
    GeminiRepository.kt           Prompt, 3x retry, time shift, glossary pass
  ui/
    PlayerViewModel.kt            Generation job, progress, resume, persistence
app/src/main/res/layout/          activity_main, dialog_edit_subtitle,
                                  dialog_settings, item_subtitle
app/src/main/res/values/          strings, colors, themes
```

## Permissions

- `READ_MEDIA_VIDEO` (Android 13+) / `READ_EXTERNAL_STORAGE` (≤12)
  — pick videos and SRT files.
- `INTERNET`, `ACCESS_NETWORK_STATE` — Gemini API.
- `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_DATA_SYNC`, `WAKE_LOCK`
  — keep generation running while the screen is off.

## Notes and limits

- Gemini's per-request audio limit is why long videos are segmented;
  45 s is a good balance of context and reliability.
- Generation needs network and a valid Gemini key with the
  Generative Language API enabled. Quota / rate-limit errors appear
  as a failed segment with the API message, and can be retried.
- The subtitle overlay is a custom `TextView` updated every 100 ms
  from ExoPlayer's position, so it stays in sync even after seeking.
