package com.burmese.subtitleplayer.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Persists the Gemini API key (encrypted), the model name, and subtitle
 * display preferences. The API key never leaves encrypted storage except
 * to be sent to Google's Gemini endpoint over HTTPS.
 */
class SettingsManager(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secure_settings",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val uiPrefs = context.getSharedPreferences("ui_settings", Context.MODE_PRIVATE)

    var geminiApiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) { prefs.edit().putString(KEY_API_KEY, value.trim()).apply() }

    val hasApiKey: Boolean get() = geminiApiKey.isNotBlank()

    /** Fixed to the model the user chose. Kept as a setting so a future model change is one edit. */
    var geminiModel: String
        get() = prefs.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) { prefs.edit().putString(KEY_MODEL, value.trim()).apply() }

    var subtitleFontSizeSp: Float
        get() = uiPrefs.getFloat(KEY_FONT_SIZE, 20f)
        set(value) { uiPrefs.edit().putFloat(KEY_FONT_SIZE, value.coerceIn(12f, 36f)).apply() }

    var subtitleBackgroundOpacity: Float
        get() = uiPrefs.getFloat(KEY_BG_OPACITY, 0.65f)
        set(value) { uiPrefs.edit().putFloat(KEY_BG_OPACITY, value.coerceIn(0f, 1f)).apply() }

    var subtitlesEnabled: Boolean
        get() = uiPrefs.getBoolean(KEY_SUBTITLES_ENABLED, true)
        set(value) { uiPrefs.edit().putBoolean(KEY_SUBTITLES_ENABLED, value).apply() }

    var lastVideoUri: String
        get() = uiPrefs.getString(KEY_LAST_VIDEO, "") ?: ""
        set(value) { uiPrefs.edit().putString(KEY_LAST_VIDEO, value).apply() }

    var segmentSeconds: Int
        get() = uiPrefs.getInt(KEY_SEGMENT_SECONDS, 45)
        set(value) { uiPrefs.edit().putInt(KEY_SEGMENT_SECONDS, value.coerceIn(20, 120)).apply() }

    fun clearApiKey() {
        prefs.edit().remove(KEY_API_KEY).apply()
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash"
        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_MODEL = "gemini_model"
        private const val KEY_FONT_SIZE = "subtitle_font_size_sp"
        private const val KEY_BG_OPACITY = "subtitle_bg_opacity"
        private const val KEY_SUBTITLES_ENABLED = "subtitles_enabled"
        private const val KEY_LAST_VIDEO = "last_video_uri"
        private const val KEY_SEGMENT_SECONDS = "segment_seconds"
    }
}
