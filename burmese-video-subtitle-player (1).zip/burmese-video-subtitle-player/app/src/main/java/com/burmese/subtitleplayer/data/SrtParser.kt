package com.burmese.subtitleplayer.data

/**
 * Parses and serialises SubRip (.srt) files.
 * Accepts CRLF or LF, comma or dot millisecond separators, and multi-line cues.
 * Never drops a cue silently: a block without a valid time range is kept
 * with its raw text so the user can edit it instead of losing it.
 */
object SrtParser {

    fun parse(content: String): List<SubtitleCue> {
        val normalised = content.replace("\r\n", "\n").replace('\r', '\n')
        val blocks = normalised.trim().split("\n\n").filter { it.isNotBlank() }
        val cues = mutableListOf<SubtitleCue>()
        var fallbackIndex = 1
        for (block in blocks) {
            val lines = block.lines().filter { it.isNotBlank() }
            if (lines.isEmpty()) continue
            var timeLineIndex = 0
            var index = lines[0].trim().toIntOrNull()
            if (index != null) {
                timeLineIndex = 1
            } else {
                index = fallbackIndex
            }
            if (timeLineIndex >= lines.size) continue
            val timeLine = lines[timeLineIndex].trim()
            if (!timeLine.contains("-->")) continue
            val timeParts = timeLine.split("-->")
            if (timeParts.size != 2) continue
            val start = SubtitleCue.parseSrtTime(timeParts[0])
            val end = SubtitleCue.parseSrtTime(timeParts[1])
            if (end <= start) continue
            val textLines = lines.drop(timeLineIndex + 1)
            if (textLines.isEmpty()) continue
            val text = textLines.joinToString("\n").trim()
            cues.add(SubtitleCue(index = index, startMs = start, endMs = end, text = text))
            fallbackIndex = index + 1
        }
        return cues.sortedBy { it.startMs }.mapIndexed { i, cue -> cue.copy(index = i + 1) }
    }

    fun serialise(cues: List<SubtitleCue>): String {
        val sorted = cues.sortedBy { it.startMs }
        val builder = StringBuilder()
        sorted.forEachIndexed { i, cue ->
            builder.append(i + 1).append("\n")
            builder.append(cue.startSrt).append(" --> ").append(cue.endSrt).append("\n")
            builder.append(cue.text.trim()).append("\n\n")
        }
        return builder.toString()
    }

    /** Find the cue active at [positionMs], or null when between cues. */
    fun cueAt(cues: List<SubtitleCue>, positionMs: Long): SubtitleCue? {
        return cues.firstOrNull { positionMs in it.startMs until it.endMs }
    }

    /** Shift every cue by [offsetMs] (positive = later). Times are clamped at zero. */
    fun shift(cues: List<SubtitleCue>, offsetMs: Long): List<SubtitleCue> {
        return cues.map {
            val start = (it.startMs + offsetMs).coerceAtLeast(0L)
            val end = (it.endMs + offsetMs).coerceAtLeast(start + 200L)
            it.copy(startMs = start, endMs = end)
        }
    }
}
