package com.burmese.subtitleplayer.data

import java.util.Locale

/**
 * One timed subtitle line. Times are in milliseconds from the start of the video.
 */
data class SubtitleCue(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val text: String
) {
    val startSrt: String get() = formatSrtTime(startMs)
    val endSrt: String get() = formatSrtTime(endMs)

    companion object {
        fun formatSrtTime(ms: Long): String {
            val totalSeconds = ms / 1000
            val millis = ms % 1000
            val hours = totalSeconds / 3600
            val minutes = (totalSeconds % 3600) / 60
            val seconds = totalSeconds % 60
            return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
        }

        fun parseSrtTime(text: String): Long {
            val cleaned = text.trim().replace('.', ',')
            val parts = cleaned.split(":", ",")
            if (parts.size != 4) return 0L
            val hours = parts[0].toLongOrNull() ?: 0L
            val minutes = parts[1].toLongOrNull() ?: 0L
            val seconds = parts[2].toLongOrNull() ?: 0L
            val millis = parts[3].toLongOrNull() ?: 0L
            return ((hours * 3600) + (minutes * 60) + seconds) * 1000 + millis
        }
    }
}

enum class SegmentStatus { PENDING, IN_PROGRESS, DONE, FAILED, SKIPPED }

data class AudioSegment(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val filePath: String,
    var status: SegmentStatus = SegmentStatus.PENDING,
    var errorMessage: String? = null,
    var attemptCount: Int = 0
)

data class GenerationProgress(
    val totalSegments: Int = 0,
    val completedSegments: Int = 0,
    val failedSegments: Int = 0,
    val currentSegmentIndex: Int = -1,
    val currentSegmentLabel: String = "",
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val message: String = ""
) {
    val percent: Int
        get() = if (totalSegments == 0) 0 else ((completedSegments * 100) / totalSegments).coerceIn(0, 100)
}
