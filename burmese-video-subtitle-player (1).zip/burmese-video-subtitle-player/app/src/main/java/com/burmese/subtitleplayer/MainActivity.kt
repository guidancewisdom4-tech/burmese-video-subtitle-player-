package com.burmese.subtitleplayer

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.burmese.subtitleplayer.data.SettingsManager
import com.burmese.subtitleplayer.data.SrtParser
import com.burmese.subtitleplayer.databinding.ActivityMainBinding
import com.burmese.subtitleplayer.databinding.DialogEditSubtitleBinding
import com.burmese.subtitleplayer.ui.PlayerViewModel
import com.google.android.material.textfield.TextInputEditText
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settings: SettingsManager
    private val viewModel: PlayerViewModel by viewModels()
    private var player: ExoPlayer? = null
    private var subtitleAdapter: SubtitleAdapter? = null
    private var currentVideoName: String = "video"

    private val pickVideoLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            loadVideo(uri)
        }
    }

    private val pickSrtLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.loadSrtFile(uri, contentResolver)
    }

    private val createSrtLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(viewModel.exportSrt().toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(this, "SRT saved.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) Toast.makeText(this, "Storage permission is needed to pick videos.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        settings = SettingsManager(this)

        setupPlayer()
        setupButtons()
        setupSubtitleControls()
        setupObservers()
        updateApiKeyStatus()
        applySubtitleStyle()

        // Handle a video shared/opened from another app.
        intent?.data?.let { uri ->
            if (intent.type?.startsWith("video/") == true || uri.toString().contains("video")) loadVideo(uri)
        }
    }

    private fun setupPlayer() {
        player = ExoPlayer.Builder(this).build().also { exo ->
            binding.playerView.player = exo
            binding.playerView.useController = true
            exo.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updateSubtitleOverlay()
                }
            })
        }
        // Poll position on the UI thread while playing to keep subtitles in sync.
        binding.playerView.post(object : Runnable {
            override fun run() {
                updateSubtitleOverlay()
                binding.playerView.postDelayed(this, 100)
            }
        })
    }

    private fun setupButtons() {
        binding.btnPickVideo.setOnClickListener { requestVideoPermissionIfNeeded { pickVideoLauncher.launch(arrayOf("video/*")) } }
        binding.btnLoadSrt.setOnClickListener { pickSrtLauncher.launch(arrayOf("application/x-subrip", "text/plain", "*/*")) }
        binding.btnGenerate.setOnClickListener { viewModel.startGeneration() }
        binding.btnResume.setOnClickListener { viewModel.resumeGeneration() }
        binding.btnPause.setOnClickListener { viewModel.pauseGeneration() }
        binding.btnRetryFailed.setOnClickListener { viewModel.retryFailedSegments() }
        binding.btnExportSrt.setOnClickListener {
            if (!viewModel.hasCues()) {
                Toast.makeText(this, "No subtitles to export yet.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            createSrtLauncher.launch("$currentVideoName.burmese.srt")
        }
        binding.btnSettings.setOnClickListener { showSettingsDialog() }
        binding.btnGlossary.setOnClickListener { showGlossaryDialog() }
    }

    private fun setupSubtitleControls() {
        binding.switchSubtitles.isChecked = settings.subtitlesEnabled
        binding.switchSubtitles.setOnCheckedChangeListener { _, checked ->
            settings.subtitlesEnabled = checked
            updateSubtitleOverlay()
        }
        binding.seekFontSize.progress = settings.subtitleFontSizeSp.toInt()
        binding.seekFontSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    settings.subtitleFontSizeSp = progress.coerceIn(12, 36).toFloat()
                    binding.tvFontSizeValue.text = "${settings.subtitleFontSizeSp.toInt()} sp"
                    applySubtitleStyle()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        binding.tvFontSizeValue.text = "${settings.subtitleFontSizeSp.toInt()} sp"

        binding.seekOpacity.progress = (settings.subtitleBackgroundOpacity * 100).toInt()
        binding.seekOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    settings.subtitleBackgroundOpacity = progress / 100f
                    binding.tvOpacityValue.text = "$progress%"
                    applySubtitleStyle()
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        binding.tvOpacityValue.text = "${(settings.subtitleBackgroundOpacity * 100).toInt()}%"
    }

    private fun setupObservers() {
        viewModel.videoUri.observe(this) { uri ->
            if (uri != null) binding.tvVideoName.text = currentVideoName
        }
        viewModel.cues.observe(this) { cues ->
            subtitleAdapter = SubtitleAdapter(cues, onEdit = { cue -> showEditDialog(cue) })
            binding.rvSubtitles.layoutManager = LinearLayoutManager(this)
            binding.rvSubtitles.adapter = subtitleAdapter
            binding.tvCueCount.text = "${cues.size} lines"
            updateSubtitleOverlay()
        }
        viewModel.progress.observe(this) { p ->
            binding.progressBar.progress = p.percent
            binding.tvProgress.text = if (p.totalSegments == 0) {
                p.message.ifEmpty { "No generation running." }
            } else {
                "${p.percent}%  •  ${p.completedSegments}/${p.totalSegments} segments" +
                    (if (p.failedSegments > 0) "  •  ${p.failedSegments} failed" else "") +
                    (if (p.currentSegmentLabel.isNotEmpty() && p.isRunning) "\n${p.currentSegmentLabel}" else "") +
                    (if (p.message.isNotEmpty()) "\n${p.message}" else "")
            }
            binding.btnResume.isEnabled = p.isPaused || p.failedSegments > 0
            binding.btnRetryFailed.isEnabled = p.failedSegments > 0 && !p.isRunning
            binding.btnPause.isEnabled = p.isRunning
            binding.btnGenerate.isEnabled = !p.isRunning
        }
        viewModel.statusMessage.observe(this) { msg ->
            if (msg.isNotBlank()) binding.tvStatus.text = msg
        }
    }

    private fun loadVideo(uri: Uri) {
        val name = queryDisplayName(uri) ?: "video"
        currentVideoName = name.substringBeforeLast(".")
        val mediaItem = MediaItem.fromUri(uri)
        player?.setMediaItem(mediaItem)
        player?.prepare()
        player?.play()
        // Duration is known after prepare; poll once for the real value.
        binding.playerView.postDelayed({
            viewModel.setVideo(uri, name, player?.duration?.coerceAtLeast(0L) ?: 0L)
        }, 600)
        binding.tvVideoName.text = name
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && idx >= 0) cursor.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun updateSubtitleOverlay() {
        val overlay = binding.tvSubtitleOverlay
        if (!settings.subtitlesEnabled) {
            overlay.visibility = View.GONE
            return
        }
        val position = player?.currentPosition ?: 0L
        val cue = SrtParser.cueAt(viewModel.cues.value ?: emptyList(), position)
        if (cue == null) {
            overlay.visibility = View.GONE
        } else {
            overlay.text = cue.text
            overlay.visibility = View.VISIBLE
        }
    }

    private fun applySubtitleStyle() {
        val overlay = binding.tvSubtitleOverlay
        overlay.textSize = settings.subtitleFontSizeSp
        val alpha = (settings.subtitleBackgroundOpacity * 255).toInt()
        overlay.setBackgroundColor(Color.argb(alpha, 0, 0, 0))
        overlay.setTextColor(Color.WHITE)
        overlay.setPadding(24, 12, 24, 12)
    }

    private fun showEditDialog(cue: com.burmese.subtitleplayer.data.SubtitleCue) {
        val dialogBinding = DialogEditSubtitleBinding.inflate(LayoutInflater.from(this))
        dialogBinding.etStartTime.setText(cue.startSrt)
        dialogBinding.etEndTime.setText(cue.endSrt)
        dialogBinding.etSubtitleText.setText(cue.text)
        AlertDialog.Builder(this)
            .setTitle("Edit subtitle ${cue.index}")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val newStart = com.burmese.subtitleplayer.data.SubtitleCue.parseSrtTime(dialogBinding.etStartTime.text.toString())
                val newEnd = com.burmese.subtitleplayer.data.SubtitleCue.parseSrtTime(dialogBinding.etEndTime.text.toString())
                val newText = dialogBinding.etSubtitleText.text.toString().trim()
                if (newText.isEmpty()) {
                    Toast.makeText(this, "Subtitle text cannot be empty.", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (newEnd <= newStart) {
                    Toast.makeText(this, "End time must be after start time.", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewModel.updateCue(cue.copy(startMs = newStart, endMs = newEnd, text = newText))
                Toast.makeText(this, "Subtitle updated.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Delete line") { _, _ ->
                viewModel.deleteCue(cue.index)
                Toast.makeText(this, "Line deleted.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showSettingsDialog() {
        val view = LayoutInflater.from(this).inflate(com.burmese.subtitleplayer.R.layout.dialog_settings, null)
        val etKey = view.findViewById<TextInputEditText>(com.burmese.subtitleplayer.R.id.etApiKey)
        val etModel = view.findViewById<TextInputEditText>(com.burmese.subtitleplayer.R.id.etModel)
        val etSegment = view.findViewById<TextInputEditText>(com.burmese.subtitleplayer.R.id.etSegmentSeconds)
        etKey.setText(settings.geminiApiKey)
        etModel.setText(settings.geminiModel)
        etSegment.setText(settings.segmentSeconds.toString())
        AlertDialog.Builder(this)
            .setTitle("Gemini Settings")
            .setView(view)
            .setPositiveButton("Save") { _, _ ->
                val key = etKey.text.toString().trim()
                val model = etModel.text.toString().trim().ifEmpty { SettingsManager.DEFAULT_MODEL }
                val segment = etSegment.text.toString().toIntOrNull()?.coerceIn(20, 120) ?: 45
                if (key.isNotEmpty()) settings.geminiApiKey = key
                settings.geminiModel = model
                settings.segmentSeconds = segment
                updateApiKeyStatus()
                Toast.makeText(this, "Settings saved.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .setNeutralButton("Clear key") { _, _ ->
                settings.clearApiKey()
                updateApiKeyStatus()
                Toast.makeText(this, "API key cleared.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showGlossaryDialog() {
        val terms = com.burmese.subtitleplayer.data.IslamicGlossary.terms
            .joinToString("\n") { "${it.english} → ${it.burmese}" }
        AlertDialog.Builder(this)
            .setTitle("Islamic terms used in translation")
            .setMessage(terms + "\n\nThese renderings are sent to Gemini with every segment and applied again as a check after generation, so the same term is always rendered the same way.")
            .setPositiveButton("Close", null)
            .show()
    }

    private fun updateApiKeyStatus() {
        binding.tvApiStatus.text = if (settings.hasApiKey) {
            "Gemini: key saved • model ${settings.geminiModel}"
        } else {
            "Gemini: no API key — tap Settings to add one."
        }
    }

    private fun requestVideoPermissionIfNeeded(onGranted: () -> Unit) {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            onGranted()
        } else {
            permissionLauncher.launch(permission)
            // The picker is launched from the button again after the user grants it.
            Toast.makeText(this, "Grant video access, then tap Pick Video again.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        super.onPause()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }

    // --- Subtitle list adapter (tap a line to edit it) ---

    inner class SubtitleAdapter(
        private val cues: List<com.burmese.subtitleplayer.data.SubtitleCue>,
        private val onEdit: (com.burmese.subtitleplayer.data.SubtitleCue) -> Unit
    ) : RecyclerView.Adapter<SubtitleAdapter.ViewHolder>() {

        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvTime: TextView = view.findViewById(com.burmese.subtitleplayer.R.id.tvCueTime)
            val tvText: TextView = view.findViewById(com.burmese.subtitleplayer.R.id.tvCueText)
        }

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(com.burmese.subtitleplayer.R.layout.item_subtitle, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val cue = cues[position]
            holder.tvTime.text = "${cue.startSrt} --> ${cue.endSrt}"
            holder.tvText.text = cue.text
            holder.itemView.setOnClickListener { onEdit(cue) }
        }

        override fun getItemCount(): Int = cues.size
    }
}
