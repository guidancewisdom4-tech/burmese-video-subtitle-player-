package com.burmese.subtitleplayer.data

import android.util.Base64
import java.io.File

/**
 * Sends one audio segment to Gemini and returns Burmese SRT cues for it.
 *
 * The prompt asks Gemini to (a) transcribe the spoken English accurately,
 * (b) translate it into clear, natural Burmese, and (c) return ONLY valid
 * SRT for that segment, with times relative to the segment start. The
 * repository then shifts those times by the segment's absolute start and
 * applies the Islamic glossary post-processing pass.
 *
 * A segment is retried up to 3 times inside [transcribeSegment] before the
 * caller marks it FAILED; the ViewModel can resume only the failed ones.
 */
class GeminiRepository(
    private val service: GeminiService = GeminiClient.create()
) {

    suspend fun transcribeSegment(
        apiKey: String,
        model: String,
        segment: AudioSegment
    ): Result<List<SubtitleCue>> {
        var lastError: Exception? = null
        repeat(3) { attempt ->
            try {
                val result = transcribeOnce(apiKey, model, segment)
                return Result.success(result)
            } catch (e: Exception) {
                lastError = e
                if (attempt < 2) {
                    kotlinx.coroutines.delay(1500L * (attempt + 1))
                }
            }
        }
        return Result.failure(lastError ?: IllegalStateException("Unknown Gemini error"))
    }

    private suspend fun transcribeOnce(
        apiKey: String,
        model: String,
        segment: AudioSegment
    ): List<SubtitleCue> {
        val audioFile = File(segment.filePath)
        if (!audioFile.exists() || audioFile.length() == 0L) {
            throw IllegalStateException("Audio segment file is missing or empty: ${segment.filePath}")
        }
        val base64Audio = Base64.encodeToString(audioFile.readBytes(), Base64.NO_WRAP)
        val mimeType = "audio/mp4"

        val prompt = buildPrompt(segment)
        val request = GeminiRequest(
            contents = listOf(
                Content(
                    parts = listOf(
                        Part(text = prompt),
                        Part(inlineData = InlineData(mimeType = mimeType, data = base64Audio))
                    )
                )
            ),
            generationConfig = GenerationConfig(temperature = 0.2, maxOutputTokens = 8192)
        )

        val response = service.generateContent(model, apiKey, request)
        if (response.error != null) {
            throw IllegalStateException("Gemini error ${response.error.code}: ${response.error.message}")
        }
        val rawText = response.candidates
            ?.firstOrNull()
            ?.content?.parts
            ?.mapNotNull { it.text }
            ?.joinToString("\n")
            ?.trim()
            ?: throw IllegalStateException("Gemini returned no text for segment ${segment.index + 1}")

        val srtText = extractSrtBlock(rawText)
        val relativeCues = SrtParser.parse(srtText)
        if (relativeCues.isEmpty()) {
            throw IllegalStateException(
                "Gemini returned no usable SRT for segment ${segment.index + 1}. Raw reply: ${rawText.take(300)}"
            )
        }
        // Shift relative times to absolute video time and apply glossary fixes.
        return relativeCues.map { cue ->
            val shifted = cue.copy(
                startMs = cue.startMs + segment.startMs,
                endMs = cue.endMs + segment.startMs
            )
            shifted.copy(text = IslamicGlossary.applyGlossary(shifted.text))
        }
    }

    private fun buildPrompt(segment: AudioSegment): String {
        val durationSeconds = (segment.endMs - segment.startMs) / 1000
        return """
You are an expert English-to-Burmese subtitle translator for Islamic educational videos.

TASK
1. Listen to the attached audio (segment ${segment.index + 1}, about $durationSeconds seconds).
2. Transcribe the spoken English accurately, word for word where possible.
3. Translate it into clear, natural, well-timed Burmese that a Burmese speaker can read comfortably while watching.
4. Return ONLY valid SRT subtitles for this segment. No explanation, no English, no markdown fences, no extra text.

TIMING RULES
- Times in the SRT are RELATIVE to the start of this audio segment (00:00:00,000 = segment start).
- Each cue should be 1-2 short lines, at most about 42 characters per line.
- A cue should last 1-6 seconds. Split long sentences at natural pauses.
- Do not overlap cues. Keep the order of speech exactly.
- If there is silence or music with no speech, return no cue for that part.

TRANSLATION QUALITY
- Translate meaning, not word-for-word. Use natural Burmese sentence order.
- Keep person names transliterated (for example Muhammad → မုဟမ္မဒ်). Never translate a name into a Burmese word.
- Keep numbers and dates as spoken, in Burmese numerals where natural.
- Do not add, omit or invent content. Do not summarise.

${IslamicGlossary.promptBlock()}

FORMAT EXAMPLE (relative times):
1
00:00:00,500 --> 00:00:03,200
အလ္လာဟ်သည် အလွန်သနားကြင်နာတော်မူသော အရှင်ဖြစ်သည်။

2
00:00:03,500 --> 00:00:06,000
တမန်တော် မုဟမ္မဒ် (ဆွ) က မိန့်တော်မူခဲ့သည်။
""".trimIndent()
    }

    /** Strips markdown fences or surrounding prose and keeps the SRT block. */
    private fun extractSrtBlock(raw: String): String {
        var text = raw.trim()
        if (text.contains("```")) {
            val fenced = Regex("```(?:srt)?\\s*(.*?)```", RegexOption.DOT_MATCHES_ALL)
                .find(text)?.groupValues?.getOrNull(1)
            if (!fenced.isNullOrBlank()) text = fenced.trim()
        }
        // If prose precedes the first numbered cue, drop everything before it.
        val firstCue = Regex("(?m)^1\\s*\\n\\d{2}:\\d{2}:\\d{2}[,.]\\d{3} -->").find(text)
        if (firstCue != null && firstCue.range.first > 0) {
            text = text.substring(firstCue.range.first)
        }
        return text
    }
}
