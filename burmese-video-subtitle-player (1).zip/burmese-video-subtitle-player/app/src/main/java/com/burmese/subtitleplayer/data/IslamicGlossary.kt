package com.burmese.subtitleplayer.data

/**
 * Canonical Burmese renderings for Islamic terms.
 *
 * These renderings are used in three places:
 *  1. In the Gemini system prompt, so the model uses them consistently.
 *  2. In [applyGlossary], a post-processing pass that repairs a literal
 *     or inconsistent rendering in generated text.
 *  3. As the reference shown in the app's glossary note.
 *
 * The spellings below follow the renderings commonly used in Burmese
 * Islamic literature. They are translation conventions, not religious
 * rulings: where a term is genuinely disputed, the app keeps the
 * transliteration and does not invent a ruling.
 */
object IslamicGlossary {

    data class Term(val english: String, val burmese: String, val note: String)

    val terms: List<Term> = listOf(
        Term("Allah", "အလ္လာဟ်", "Always အလ္လာဟ်, never 'ဘုရားသခင်' as a generic god."),
        Term("God", "အလ္လာဟ်", "When referring to Allah in an Islamic context, use အလ္လာဟ်."),
        Term("Prophet Muhammad", "တမန်တော် မုဟမ္မဒ် (ဆွ)", "Use တမန်တော်, with (ဆွ) after the name."),
        Term("Prophet / Messenger", "တမန်တော်", "Prophet and Messenger both render as တမန်တော် in this app."),
        Term("Quran / Qur'an", "ကုရ်အာန်", "Keep as ကုရ်အာန်, not a literal 'book' translation."),
        Term("Hadith", "ဟဒီးစ်", "Keep as ဟဒီးစ်."),
        Term("Sunnah", "စွန္နသ်", "Keep as စွန္နသ်."),
        Term("Salah / Prayer", "ဆွလားသ်", "The ritual prayer is ဆွလားသ်, not generic ဆုတောင်းခြင်း."),
        Term("Dua / Du'a", "ဒိုအာ", "Keep as ဒိုအာ."),
        Term("Dhikr", "ဇိကိရ်", "Keep as ဇိကိရ်."),
        Term("Tawheed", "သဝ်ဟီးဒ်", "Oneness of Allah — သဝ်ဟီးဒ်."),
        Term("Taqwa", "သက္ကဝါ", "God-consciousness — သက္ကဝါ."),
        Term("Halal", "ဟလာလ်", "Permissible — ဟလာလ်."),
        Term("Haram", "ဟရာမ်", "Forbidden — ဟရာမ်."),
        Term("Ummah", "အွမ္မသ်", "The Muslim community — အွမ္မသ်."),
        Term("Iman / Faith", "အီမာန်", "Faith — အီမာန်."),
        Term("Islam", "အစ္စလာမ်", "Keep as အစ္စလာမ်."),
        Term("Muslim", "မွတ်စလင်", "Keep as မွတ်စလင်."),
        Term("Ramadan", "ရမဿွာန်", "Keep as ရမဿွာန်."),
        Term("Zakat", "ဇကားသ်", "Keep as ဇကားသ်."),
        Term("Hajj", "ဟဂ်ျ", "Keep as ဟဂ်ျ."),
        Term("Shariah", "ရှရီအသ်", "Keep as ရှရီအသ်."),
        Term("Akhlaq", "အခလာက်", "Character / manners — အခလာက်."),
        Term("Seerah", "စီရသ်", "Life of the Prophet — စီရသ်."),
        Term("Sahaba", "ဆွဟာဗာ", "Companions — ဆွဟာဗာ."),
        Term("Masjid / Mosque", "မတ်စ်ဂျိဒ်", "Keep as မတ်စ်ဂျိဒ်."),
        Term("Wudu / Ablution", "ဝူဇူ", "Keep as ဝူဇူ."),
        Term("Jannah / Paradise", "ဂျန္နသ်", "Keep as ဂျန္နသ်."),
        Term("Jahannam / Hellfire", "ဂျဟန္နမ်", "Keep as ဂျဟန္နမ်.")
    )

    /** Glossary text inserted verbatim into the Gemini prompt. */
    fun promptBlock(): String {
        val lines = terms.joinToString("\n") { "- ${it.english} → ${it.burmese} (${it.note})" }
        return "ISLAMIC TERMINOLOGY — USE THESE BURMESE RENDERINGS CONSISTENTLY, DO NOT TRANSLATE THEM LITERALLY:\n$lines\n" +
            "Rules: preserve the religious meaning exactly; never use irreverent, joking or casual phrasing " +
            "for Allah, the Prophet, the Quran or worship; keep Arabic names transliterated, not translated; " +
            "when unsure between a literal Burmese word and the term above, always use the term above."
    }

    /**
     * Light post-processing: repairs the most common literal mistranslations
     * in generated Burmese text. It only replaces whole-word patterns that
     * are known to be wrong in this context; it never rewrites a sentence.
     */
    fun applyGlossary(text: String): String {
        var result = text
        val fixes = mapOf(
            "ဘုရားသခင်" to "အလ္လာဟ်",
            "ဘုရား" to "အလ္လာဟ်",
            "ကျမ်း" to "ကုရ်အာန်",
            "ဆုတောင်းခြင်း" to "ဆွလားသ်"
        )
        for ((wrong, right) in fixes) {
            if (result.contains(wrong)) {
                result = result.replace(wrong, right)
            }
        }
        return result
    }
}
