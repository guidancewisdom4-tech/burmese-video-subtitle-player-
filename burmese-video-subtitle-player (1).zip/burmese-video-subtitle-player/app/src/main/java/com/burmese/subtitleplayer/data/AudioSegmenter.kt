package com.burmese.subtitleplayer.data

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File

/**
 * Splits a video's audio track into short segments that Gemini can accept
 * in one request. Each segment is written as a standalone .m4a file in the
 * app cache directory using MediaExtractor + MediaMuxer — no external
 * native binary is required.
 *
 * Segment length defaults to 45 seconds: long enough for context, short
 * enough to stay inside Gemini's per-request audio limits and to make a
 * failed segment cheap to retry.
 */
class AudioSegmenter(private val context: Context) {

    data class SplitResult(
        val segments: List<AudioSegment>,
        val durationMs: Long,
        val hasAudioTrack: Boolean
    )

    fun splitIntoSegments(videoUri: Uri, segmentSeconds: Int = 45): SplitResult {
        val outputDir = File(context.cacheDir, "audio_segments").apply {
            if (!exists()) mkdirs()
            listFiles()?.forEach { it.delete() }
        }

        val extractor = MediaExtractor()
        extractor.setDataSource(context, videoUri, null)
        var audioTrackIndex = -1
        var audioFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                audioFormat = format
                break
            }
        }
        if (audioTrackIndex < 0 || audioFormat == null) {
            extractor.release()
            return SplitResult(emptyList(), 0L, hasAudioTrack = false)
        }

        val durationUs = audioFormat.getLong(MediaFormat.KEY_DURATION)
        val durationMs = durationUs / 1000
        val segmentMs = segmentSeconds * 1000L
        val segmentCount = ((durationMs + segmentMs - 1) / segmentMs).toInt().coerceAtLeast(1)

        extractor.selectTrack(audioTrackIndex)
        val segments = mutableListOf<AudioSegment>()

        for (segmentIndex in 0 until segmentCount) {
            val segmentStartMs = segmentIndex * segmentMs
            val segmentEndMs = minOf(segmentStartMs + segmentMs, durationMs)
            val outFile = File(outputDir, "segment_%03d.m4a".format(segmentIndex + 1))

            val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerTrackIndex = muxer.addTrack(audioFormat)
            muxer.start()

            extractor.seekTo(segmentStartMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val bufferSize = 256 * 1024
            val buffer = java.nio.ByteBuffer.allocate(bufferSize)
            val bufferInfo = android.media.MediaCodec.BufferInfo()

            while (true) {
                buffer.clear()
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs >= segmentEndMs * 1000) break
                if (sampleTimeUs < segmentStartMs * 1000) {
                    extractor.advance()
                    continue
                }
                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = sampleTimeUs - (segmentStartMs * 1000)
                bufferInfo.flags = extractor.sampleFlags
                muxer.writeSampleData(muxerTrackIndex, buffer, bufferInfo)
                extractor.advance()
            }
            muxer.stop()
            muxer.release()

            segments.add(
                AudioSegment(
                    index = segmentIndex,
                    startMs = segmentStartMs,
                    endMs = segmentEndMs,
                    filePath = outFile.absolutePath
                )
            )
        }
        extractor.release()
        return SplitResult(segments, durationMs, hasAudioTrack = true)
    }
}
