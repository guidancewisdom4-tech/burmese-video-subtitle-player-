package com.burmese.subtitleplayer.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.burmese.subtitleplayer.data.AudioSegment
import com.burmese.subtitleplayer.data.AudioSegmenter
import com.burmese.subtitleplayer.data.GeminiRepository
import com.burmese.subtitleplayer.data.GenerationProgress
import com.burmese.subtitleplayer.data.SegmentStatus
import com.burmese.subtitleplayer.data.SettingsManager
import com.burmese.subtitleplayer.data.SrtParser
import com.burmese.subtitleplayer.data.SubtitleCue
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Owns video/subtitle state and the Gemini generation job.
 *
 * Resume behaviour: generation progress is persisted to
 * [PROGRESS_FILE] after every segment (completed cues + per-segment
 * status). Pausing, a failed segment, or the app being killed does not
 * lose completed work — [resumeGeneration] re-splits the same video,
 * restores the saved cues, and processes only PENDING / FAILED segments.
 */
class PlayerViewModel(application: Application) : AndroidViewModel(application) {

    private val settings = SettingsManager(application)
    private val segmenter = AudioSegmenter(application)
    private val repository = GeminiRepository()
    private val appContext: Context get() = getApplication()

    private var generationJob: Job? = null
    private var segments: MutableList<AudioSegment> = mutableListOf()
    private var currentVideoUri: Uri? = null
    private var currentVideoName: String = ""

    private val _cues = MutableLiveData<List<SubtitleCue>>(emptyList())
    val cues: LiveData<List<SubtitleCue>> = _cues

    private val _progress = MutableLiveData(GenerationProgress())
    val progress: LiveData<GenerationProgress> = _progress

    private val _statusMessage = MutableLiveData<String>("")
    val statusMessage: LiveData<String> = _statusMessage

    private val _videoUri = MutableLiveData<Uri?>()
    val videoUri: LiveData<Uri?> = _videoUri

    private val _videoDurationMs = MutableLiveData(0L)
    val videoDurationMs: LiveData<Long> = _videoDurationMs

    fun setVideo(uri: Uri, displayName: String, durationMs: Long) {
        currentVideoUri = uri
        currentVideoName = displayName
        _videoUri.value = uri
        _videoDurationMs.value = durationMs
        settings.lastVideoUri = uri.toString()
        _statusMessage.value = "Video loaded: $displayName"
        restoreProgressIfPresent(uri)
    }

    fun loadSrtFile(uri: Uri, contentResolver: android.content.ContentResolver) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText()
                ?: throw IllegalStateException("Could not read the SRT file.")
            val parsed = SrtParser.parse(text)
            if (parsed.isEmpty()) {
                _statusMessage.value = "That SRT file contains no usable cues. Check the file and try again."
                return
            }
            _cues.value = parsed
            _statusMessage.value = "Loaded ${parsed.size} subtitle lines from SRT — no API call made."
        } catch (e: Exception) {
            _statusMessage.value = "Could not load SRT: ${e.message}"
        }
    }

    fun startGeneration() {
        val uri = currentVideoUri
        if (uri == null) {
            _statusMessage.value = "Pick a video first."
            return
        }
        if (!settings.hasApiKey) {
            _statusMessage.value = "Save your Gemini API key first (Settings)."
            return
        }
        if (generationJob?.isActive == true) return
        generationJob = viewModelScope.launch {
            runGeneration(uri, fromScratch = true)
        }
    }

    fun resumeGeneration() {
        val uri = currentVideoUri ?: return
        if (!settings.hasApiKey) {
            _statusMessage.value = "Save your Gemini API key first (Settings)."
            return
        }
        if (generationJob?.isActive == true) return
        generationJob = viewModelScope.launch {
            runGeneration(uri, fromScratch = false)
        }
    }

    fun pauseGeneration() {
        generationJob?.cancel()
        generationJob = null
        val p = _progress.value ?: GenerationProgress()
        _progress.value = p.copy(isRunning = false, isPaused = true, message = "Paused — tap Resume to continue the remaining segments.")
        _statusMessage.value = "Paused. Completed segments are saved; Resume continues from where it stopped."
    }

    fun retryFailedSegments() {
        val uri = currentVideoUri ?: return
        if (generationJob?.isActive == true) return
        generationJob = viewModelScope.launch {
            runGeneration(uri, fromScratch = false, onlyFailed = true)
        }
    }

    private suspend fun runGeneration(uri: Uri, fromScratch: Boolean, onlyFailed: Boolean = false) {
        _progress.value = GenerationProgress(isRunning = true, message = "Splitting audio into segments…")
        try {
            val split = segmenter.splitIntoSegments(uri, settings.segmentSeconds)
            if (!split.hasAudioTrack) {
                _progress.value = GenerationProgress(message = "This video has no audio track to transcribe.")
                _statusMessage.value = "No audio track found in this video."
                return
            }
            if (fromScratch) {
                segments = split.segments.toMutableList()
                _cues.value = emptyList()
                clearProgressFile()
            } else {
                // Re-split, then restore saved statuses by segment index.
                val savedStatuses = segments.associate { it.index to it.status }
                segments = split.segments.toMutableList()
                segments.forEach { seg ->
                    seg.status = savedStatuses[seg.index] ?: SegmentStatus.PENDING
                }
                if (segments.all { it.status == SegmentStatus.DONE }) {
                    _progress.value = GenerationProgress(
                        totalSegments = segments.size,
                        completedSegments = segments.size,
                        isRunning = false,
                        message = "All segments are already done."
                    )
                    return
                }
            }

            val total = segments.size
            var completed = segments.count { it.status == SegmentStatus.DONE }
            var failed = segments.count { it.status == SegmentStatus.FAILED }
            val allCues = (_cues.value ?: emptyList()).toMutableList()

            for (segment in segments) {
                if (!viewModelScope.isActive) return
                if (segment.status == SegmentStatus.DONE) continue
                if (onlyFailed && segment.status != SegmentStatus.FAILED) continue
                if (segment.status == SegmentStatus.SKIPPED) continue

                segment.status = SegmentStatus.IN_PROGRESS
                segment.attemptCount++
                _progress.value = GenerationProgress(
                    totalSegments = total,
                    completedSegments = completed,
                    failedSegments = failed,
                    currentSegmentIndex = segment.index,
                    currentSegmentLabel = "Segment ${segment.index + 1} of $total  (${segment.startMs / 1000}s – ${segment.endMs / 1000}s)",
                    isRunning = true,
                    message = "Transcribing segment ${segment.index + 1} of $total…"
                )

                val result = repository.transcribeSegment(settings.geminiApiKey, settings.geminiModel, segment)
                if (result.isSuccess) {
                    val newCues = result.getOrThrow()
                    segment.status = SegmentStatus.DONE
                    completed++
                    allCues.addAll(newCues)
                    allCues.sortBy { it.startMs }
                    val renumbered = allCues.mapIndexed { i, cue -> cue.copy(index = i + 1) }
                    allCues.clear()
                    allCues.addAll(renumbered)
                    _cues.value = allCues.toList()
                    saveProgress()
                } else {
                    segment.status = SegmentStatus.FAILED
                    segment.errorMessage = result.exceptionOrNull()?.message
                    failed++
                    saveProgress()
                }
                _progress.value = GenerationProgress(
                    totalSegments = total,
                    completedSegments = completed,
                    failedSegments = failed,
                    currentSegmentIndex = segment.index,
                    isRunning = true,
                    message = if (failed > 0) "$completed of $total done, $failed failed — you can retry the failed ones." else "$completed of $total segments done."
                )
            }

            val remainingFailed = segments.count { it.status == SegmentStatus.FAILED }
            _progress.value = GenerationProgress(
                totalSegments = total,
                completedSegments = completed,
                failedSegments = remainingFailed,
                isRunning = false,
                message = if (remainingFailed == 0) "Done — ${allCues.size} subtitle lines generated."
                else "Finished with $remainingFailed failed segment(s). Tap “Retry failed” to try them again."
            )
            _statusMessage.value = if (remainingFailed == 0) {
                "Subtitles ready: ${allCues.size} lines. You can edit any line, then export the SRT."
            } else {
                "$remainingFailed segment(s) failed. Completed lines are kept — retry only the failed ones."
            }
            if (remainingFailed == 0) clearProgressFile()
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) {
                _progress.value = (_progress.value ?: GenerationProgress()).copy(isRunning = false, isPaused = true)
            } else {
                _progress.value = GenerationProgress(isRunning = false, message = "Generation stopped: ${e.message}")
                _statusMessage.value = "Generation error: ${e.message}"
            }
        }
    }

    fun updateCue(edited: SubtitleCue) {
        val current = _cues.value ?: emptyList()
        _cues.value = current.map { if (it.index == edited.index) edited else it }
        saveProgress()
    }

    fun deleteCue(index: Int) {
        val current = (_cues.value ?: emptyList()).filter { it.index != index }
        _cues.value = current.mapIndexed { i, cue -> cue.copy(index = i + 1) }
        saveProgress()
    }

    fun exportSrt(): String = SrtParser.serialise(_cues.value ?: emptyList())

    fun hasCues(): Boolean = !(_cues.value.isNullOrEmpty())

    // --- Progress persistence (resume across pause / restart) ---

    private fun progressFile(): File = File(appContext.filesDir, PROGRESS_FILE)

    private fun saveProgress() {
        try {
            val json = JSONObject()
            json.put("videoUri", currentVideoUri?.toString() ?: "")
            json.put("videoName", currentVideoName)
            val cueArray = JSONArray()
            (_cues.value ?: emptyList()).forEach { cue ->
                cueArray.put(JSONObject().apply {
                    put("index", cue.index)
                    put("startMs", cue.startMs)
                    put("endMs", cue.endMs)
                    put("text", cue.text)
                })
            }
            json.put("cues", cueArray)
            val segArray = JSONArray()
            segments.forEach { seg ->
                segArray.put(JSONObject().apply {
                    put("index", seg.index)
                    put("status", seg.status.name)
                    put("error", seg.errorMessage ?: "")
                })
            }
            json.put("segments", segArray)
            progressFile().writeText(json.toString(), Charsets.UTF_8)
        } catch (e: Exception) {
            // Persistence is best-effort; generation in memory continues.
        }
    }

    private fun restoreProgressIfPresent(uri: Uri) {
        try {
            val file = progressFile()
            if (!file.exists()) return
            val json = JSONObject(file.readText(Charsets.UTF_8))
            if (json.optString("videoUri") != uri.toString()) return
            val cues = mutableListOf<SubtitleCue>()
            val cueArray = json.optJSONArray("cues") ?: JSONArray()
            for (i in 0 until cueArray.length()) {
                val o = cueArray.getJSONObject(i)
                cues.add(SubtitleCue(o.getInt("index"), o.getLong("startMs"), o.getLong("endMs"), o.getString("text")))
            }
            if (cues.isNotEmpty()) {
                _cues.value = cues.sortedBy { it.startMs }
                val segArray = json.optJSONArray("segments") ?: JSONArray()
                segments = mutableListOf()
                for (i in 0 until segArray.length()) {
                    val o = segArray.getJSONObject(i)
                    segments.add(
                        AudioSegment(
                            index = o.getInt("index"),
                            startMs = 0L,
                            endMs = 0L,
                            filePath = "",
                            status = SegmentStatus.valueOf(o.optString("status", "PENDING")),
                            errorMessage = o.optString("error").ifEmpty { null }
                        )
                    )
                }
                val done = segments.count { it.status == SegmentStatus.DONE }
                _progress.value = GenerationProgress(
                    totalSegments = segments.size,
                    completedSegments = done,
                    failedSegments = segments.count { it.status == SegmentStatus.FAILED },
                    isRunning = false,
                    isPaused = true,
                    message = "Restored $done saved segment(s). Tap Resume to continue."
                )
                _statusMessage.value = "Restored ${cues.size} saved subtitle lines for this video. Tap Resume to continue."
            }
        } catch (e: Exception) {
            // Corrupt progress file: start clean rather than crash.
            clearProgressFile()
        }
    }

    private fun clearProgressFile() {
        try { progressFile().delete() } catch (e: Exception) { }
    }

    companion object {
        private const val PROGRESS_FILE = "generation_progress.json"
    }
}
